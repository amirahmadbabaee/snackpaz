# راهنمای بیلد و انتشار بازی «دختر اسنک‌پز»

این راهنما نحوه‌ی انتشار نسخه‌ی وب، ساخت APK/AAB اندروید برای Play Store، و ساخت اپ iOS برای App Store را توضیح می‌دهد.

توسعه‌دهنده: امیراحمد بابائی (amirahmadbabee) | برند: اسنک‌پز (@snackpaz)

---

## ۰) معماری در یک نگاه

```
┌────────────────────┐     ┌──────────────────────────┐
│  اپ موبایل         │     │  بک‌اند + نسخه‌ی وب       │
│  (Capacitor APK/   │ ──> │  (Next.js روی Vercel)    │
│   iOS)             │     │  - احراز هویت (NextAuth) │
│  WebView ←─────────┼─────┤  - API /api/scores       │
│  بارگذاری URL      │     │  - پایگاه‌داده Prisma     │
└────────────────────┘     │  - جدول امتیاز آنلاین    │
                           └──────────────────────────┘
```

اپ موبایل نسخه‌ی وبِ دیپلوی‌شده را در WebView بارگذاری می‌کند، بنابراین احراز هویت، ذخیره‌ی امتیاز و جدول آنلاین همه از همان بک‌اند کار می‌کنند.

---

## ۱) انتشار نسخه‌ی وب روی Vercel (الزامی قبل از بیلد موبایل)

1. کد پروژه را در یک ریپو Git (GitHub/GitLab) قرار بده.
2. وارد https://vercel.com شو، «New Project» → ریپو را انتخاب کن.
3. متغیرهای محیطی را در Vercel تنظیم کن (Settings → Environment Variables):
   - `DATABASE_URL` = `file:./db/prod.db` (یا یک دیتابیس خارجی PostgreSQL؛ برای مقیاس واقعی توصیه می‌شود)
   - `NEXTAUTH_SECRET` = یک رشته‌ی تصادفی ۳۲ کاراکتری (با `openssl rand -base64 32` بساز)
   - `NEXTAUTH_URL` = نشانی دیپلوی (مثلاً `https://snackpaz.vercel.app`)
4. Deploy. پس از موفقیت، نشانی پروژه (مثلاً `https://snackpaz.vercel.app`) را یادداشت کن.

> نکته: SQLite روی Vercel فقط برای دمو/حجم کم مناسب است. برای کاربران زیاد، Prisma را به PostgreSQL (Neon/Supabase/Vercel Postgres) تغییر بده: در `prisma/schema.prisma` خط `provider = "sqlite"` را به `"postgresql"` تغییر بده و `DATABASE_URL` را تنظیم کن.

---

## ۲) تنظیم نشانی وب در Capacitor

فایل `capacitor.config.ts` را باز کن و `WEB_URL` را با نشانی دیپلوی واقعی جایگزین کن:

```ts
const WEB_URL = 'https://snackpaz.vercel.app'; // ← نشانی خودت
```

یا با متغیر محیطی هنگام بیلد:
```bash
SNACKPAZ_WEB_URL=https://snackpaz.vercel.app bunx cap sync
```

---

## ۳) بیلد APK/AAB اندروید

### پیش‌نیازها (روی ماشین خودت)
- JDK 21
- Android SDK (Platform 35 + Build-Tools 35.0.0 + Platform-Tools)
- متغیر `ANDROID_HOME` به مسیر SDK

### بیلد APK دیباگ (برای تست سریع)
```bash
cd android
./gradlew assembleDebug
# خروجی: android/app/build/outputs/apk/debug/app-debug.apk
```

### بیلد AAB امضا‌شده (برای Play Store)
Play Store فقط فایل `.aab` (Android App Bundle) می‌پذیرد.

۱. یک keystore بساز (یک‌بار برای همیشه):
```bash
keytool -genkey -v -keystore snackpaz-release.keystore \
  -alias snackpaz -keyalg RSA -keysize 2048 -validity 10000
```
رمز و اطلاعات را امن نگه‌دار!

۲. فایل `android/app/key.properties` بساز:
```properties
storeFile=../snackpaz-release.keystore
storePassword=رمز-keystore
keyAlias=snackpaz
keyPassword=رمز-key
```

۳. در `android/app/build.gradle` بخش signingConfigs اضافه کن و در buildType release فعالش کن (اگه هست، فقط مقادیر را پر کن).

۴. بیلد:
```bash
cd android
./gradlew bundleRelease
# خروجی: android/app/build/outputs/bundle/release/app-release.aab
```

۵. در Play Console (چون اکانت Google Play Developer داری):
   - «Create app» → نام، زبان، نوع (Game) را تنظیم کن.
   - آپلود `app-release.aab` در Release → Production (یا Internal Testing برای تست اولیه).
   - تصاویر، توضیحات، آیکون، دسته‌بندی بازی را کامل کن.
   - appId: `com.snackpaz.game`

---

## ۴) بیلد iOS (فقط روی macOS)

> ساخت iOS فقط روی Mac با Xcode ممکن است. روی Linux قابل‌اجر نیست.

۱. پیش‌نیاز: macOS + Xcode 15+ و اپل‌آیدی توسعه‌دهنده (Apple Developer Program — ۹۹ دلار/سال).

۲. پلتفرم iOS از قبل اضافه شده است (`ios/`).

۳. باز کردن پروژه در Xcode:
```bash
bunx cap open ios
```

۴. در Xcode:
   - Team (Apple ID توسعه‌دهنده) را تنظیم کن.
   - Bundle Identifier را تأیید کن: `com.snackpaz.game`.
   - App Icons را اضافه کن (از `android/app/src/main/res/` یا یک فایل ۱۰۲۴×۱۰۲۴).
   - در Info.plist، تنظیمات ATS (App Transport Security) را برای اجازه‌ی بارگذاری URL دیپلوی چک کن (چون `cleartext=true` فعال است؛ برای تولید فقط https استفاده کن و cleartext را بردار).

۵. Archive: Product → Archive → سپس TestFlight یا App Store Connect.

---

## ۵) تنظیمات نهایی برند و انتشار

- **آیکون اپ:** یک آیکون ۱۰۲۴×۱۰۲۴ از لوگوی اسنک‌پز بساز و در `android/app/src/main/res/` (mipmap-*) و `ios/App/App/Assets.xcassets/AppIcon.appiconset/` قرار بده.
- **Splash screen:** در `android/app/src/main/res/drawable/` و `ios/App/App/Assets.xcassets/Splash.imageset/`.
- **نام اپ:** «اسنک پز» (هم‌اکنون در `capacitor.config.ts` تنظیم شده).
- **@snackpaz و آدرس مغازه:** داخل بازی نمایش داده می‌شوند (دکمه «بیا ببینمغازه!»).

---

## ۶) جریان کاربری (User Flow)

1. کاربر اپ را باز می‌کند → منو با «ورود/ثبت‌نام» و «جدول امتیاز».
2. ثبت‌نام با ایمیل + رمز + نام → اکانت در بک‌اند ساخته می‌شود.
3. بازی می‌کند → در پایان، امتیاز به اکانتش ذخیره می‌شود (POST /api/scores).
4. در «جدول امتیاز»، ۱۰ نفر برتر + رتبه‌ی خودش را می‌بیند.
5. ورود در دستگاه دیگر → امتیازها و رکوردش همراهش است (در سرور).

---

## ۷) خروجی‌های فعلی

- ✅ فایل APK دیباگ: `download/snackpaz-game-debug.apk` (قابل نصب روی اندروید برای تست؛ نشانه‌گذاری دیباگ).
- ✅ پروژه‌ی Android آماده: `android/` (برای `bundleRelease`).
- ✅ پروژه‌ی iOS آماده: `ios/` (برای باز شدن در Xcode).
- ✅ نسخه‌ی وب + بک‌اند احراز هویت + جدول امتیاز (در حال اجرا).

---

سوالی بود بپرس! 🌽
