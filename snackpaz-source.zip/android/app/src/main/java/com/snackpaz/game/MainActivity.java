package com.snackpaz.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
